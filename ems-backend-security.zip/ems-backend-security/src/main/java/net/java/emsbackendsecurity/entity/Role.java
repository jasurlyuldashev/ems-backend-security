package net.java.emsbackendsecurity.entity;

public enum Role {

    USER,

    ADMIN
}
