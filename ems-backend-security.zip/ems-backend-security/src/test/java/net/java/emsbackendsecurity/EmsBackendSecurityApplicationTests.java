package net.java.emsbackendsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmsBackendSecurityApplicationTests {

    @Test
    void contextLoads() {
    }

}
